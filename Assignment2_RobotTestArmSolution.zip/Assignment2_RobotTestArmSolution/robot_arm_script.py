import re
import sys
from pathlib import Path



BASE_DIR = Path(__file__).resolve().parent

INPUT_FILE = BASE_DIR / "system_input_file.1630412935.txt"
OUTPUT_FILE = BASE_DIR / "system_ouput_file.1630412935.txt"
RESULT_FILE = BASE_DIR / "test_results.txt"


def read_points(text):
    points = []
    errors = []
    for line in text.splitlines():
        line = line.strip()
        if not line:
            continue
        matches = re.findall(
            r"\(\s*(-?\d+(?:\.\d+)?)\s*,\s*(-?\d+(?:\.\d+)?)\s*\)",
            line
        )

        if matches:
            for x, y in matches:
                points.append((float(x), float(y)))
        else:
            errors.append(line)
    return points, errors


def inside(point, xmin, xmax, ymin, ymax):
    x, y = point
    return xmin <= x <= xmax and ymin <= y <= ymax


def show(points):
    return ", ".join(f"({x:g}, {y:g})" for x, y in points) or "(none)"


def main():
    input_file = sys.argv[1] if len(sys.argv) > 1 else INPUT_FILE
    output_file = sys.argv[2] if len(sys.argv) > 2 else OUTPUT_FILE

    try:
        input_text = Path(input_file).read_text()
        output_text = Path(output_file).read_text()
    except OSError as error:
        print(f"FAIL: Cannot read file: {error}")
        Path(RESULT_FILE).write_text(
            "Expected visited points\tActual visited points\tTest result (PASS / FAIL)\n"
            f"(unknown)\t(unknown)\tFAIL - {error}\n"
        )
        sys.exit(1)

    rectangle_text = input_text.split("Points", 1)[0]
    corners, _ = read_points(rectangle_text)
    if len(corners) < 4:
        print("FAIL: Could not read the rectangle from the input file.")
        sys.exit(1)

    xs = [point[0] for point in corners]
    ys = [point[1] for point in corners]
    xmin, xmax, ymin, ymax = min(xs), max(xs), min(ys), max(ys)

    points_text = input_text.split("Points", 1)[1]
    input_points, bad_input_lines = read_points(points_text)
    expected_visited_points = [p for p in input_points if inside(p, xmin, xmax, ymin, ymax)]

    actual_visited_points, bad_output_lines = read_points(output_text)
    failures = []

    if bad_input_lines:
        failures.append("Input contains malformed point lines.")
    if bad_output_lines:
        failures.append(f"Output contains {bad_output_lines} malformed line(s).")
    if any(not inside(p, xmin, xmax, ymin, ymax) for p in actual_visited_points):
        failures.append("Output contains point(s) outside the rectangle.")
    if len(expected_visited_points) != len(actual_visited_points) or any(
        expected != actual
        for expected, actual in zip(
            expected_visited_points,
            actual_visited_points
        )
    ):
        failures.append("Actual points do not match expected points in order.")

    result = "PASS" if not failures else "FAIL"
    Path(RESULT_FILE).write_text(
        "Expected visited points\tActual visited points\tTest result (PASS / FAIL)\n"
        f"{show(expected_visited_points)}\t{show(actual_visited_points)}\t{result}\n"
    )

    if failures:
        print("FAIL:")
        for failure in failures:
            print(f"- {failure}")
    else:
        print("PASS: All requirements are met.")

    print(f"Results saved in {RESULT_FILE}")
    sys.exit(0 if result == "PASS" else 1)


if __name__ == "__main__":
    main()
