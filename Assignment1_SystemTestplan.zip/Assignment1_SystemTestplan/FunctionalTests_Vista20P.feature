Feature: VISTA-20P Home Security System - Functional Requirements

  Background:
    Given the VISTA-20P system is installed and operational

  Rule: Only an authorized user can change the security state

    @SYS-001 @ST-001
    Scenario: Authorized user arms and disarms the system
      Given an authorized user is configured
      And the system is disarmed
      When the user enters a valid credential and requests arming
      Then the system becomes armed
      When the user enters a valid credential and requests disarming
      Then the system becomes disarmed

    @SYS-001 @ST-002
    Scenario: Invalid credential cannot change the security state
      Given the system is armed
      When a user enters an invalid credential and requests disarming
      Then the system remains armed
      And the disarming request is rejected

  Rule: A configured single-button command can arm the system

    @SYS-002 @ST-003
    Scenario: Configured arm button arms the system
      Given single-button arming is configured
      And the system is disarmed
      When the user presses the configured arm button
      Then the system becomes armed

    @SYS-002 @ST-004
    Scenario: Unconfigured button does not arm the system
      Given the system is disarmed
      And a button is not configured for arming
      When the user presses that button
      Then the system remains disarmed

  Rule: Activating the configured key switch arms the system

    @SYS-003 @ST-005
    Scenario: Configured key switch arms the system
      Given the key switch is configured for arming
      And the system is disarmed
      When the user activates the key switch
      Then the system becomes armed

  Rule: Commands from a registered wireless remote are processed

    @SYS-004 @ST-006
    Scenario: Registered wireless remote arms the system
      Given a wireless remote is registered
      And the remote is configured for arming
      And the system is disarmed
      When the user sends an arm command from the remote
      Then the system becomes armed

    @SYS-004 @ST-007
    Scenario: Unregistered wireless remote cannot change system state
      Given the system is disarmed
      And a wireless remote is not registered
      When the remote sends an arm command
      Then the system remains disarmed
      And the command is not executed

  Rule: Only authorized telephone commands can control the system

    @SYS-005 @ST-008
    Scenario: Authorized telephone command arms the system
      Given telephone control is configured
      And the caller is authorized
      And the system is disarmed
      When the caller sends a valid arm command
      Then the system becomes armed

    @SYS-005 @ST-009
    Scenario: Unauthorized telephone command is rejected
      Given telephone control is configured
      And the system is disarmed
      When an unauthorized caller sends an arm command
      Then the system remains disarmed
      And the command is rejected

  Rule: Exit countdown is displayed while the exit delay is active

    @SYS-006 @ST-010
    Scenario: Keypad displays the exit countdown during arming
      Given an exit delay is configured
      And the system is disarmed
      When the user initiates arming
      Then the keypad displays the exit countdown
      And the displayed countdown reflects the configured exit delay

    @SYS-006 @ST-011
    Scenario: Exit countdown is not displayed when no exit delay is active
      Given the system is disarmed
      And no arming transition is in progress
      When the user views the keypad
      Then no active exit countdown is displayed

  Rule: The keypad displays the configured system time and date

    @SYS-007 @ST-012
    Scenario: Keypad displays the configured system time and date
      Given the system clock is configured
      When the user views the keypad
      Then the displayed time matches the system clock
      And the displayed date matches the system clock

  Rule: System events are recorded and available to the user

    @SYS-008 @ST-013
    Scenario: Alarm event is recorded with a timestamp
      Given event logging is operational
      And the system is armed
      When an intrusion alarm occurs
      Then the event log contains the alarm event
      And the event includes a date and time stamp
      And the event is viewable through the supported keypad

  Rule: The event log is limited to 100 events

    @SYS-008 @ST-014
    Scenario: Event log handles its 100-event capacity
      Given the event log contains fewer than 100 events
      When sufficient supported events are generated to reach 100 entries
      Then the event log contains up to 100 events
      And the system remains operational
      When additional events are generated
      Then the event log handles capacity according to its specified retention policy

  Rule: Entry activates keypad illumination

    @SYS-009 @ST-015
    Scenario: Entry activates keypad backlighting
      Given keypad backlighting is configured
      When the configured entry condition occurs
      Then the keypad backlight activates

  Rule: Independent partitions can have different security states

    @SYS-010 @ST-016
    Scenario: Partitions maintain independent security states
      Given Partition 1 and Partition 2 are configured
      And both partitions are disarmed
      When Partition 1 is armed
      Then Partition 1 becomes armed
      And Partition 2 remains disarmed

    @SYS-010 @ST-017
    Scenario: Arming one partition does not unintentionally arm another
      Given Partition 1 is disarmed
      And Partition 2 is disarmed
      When an authorized user arms Partition 1 only
      Then Partition 1 becomes armed
      And Partition 2 remains disarmed

  Rule: Global arming arms all applicable partitions

    @SYS-011 @ST-018
    Scenario: Global arming arms all applicable partitions
      Given the applicable partitions are configured
      And the user has permission for global arming
      When the user initiates global arming from a system keypad
      Then all applicable partitions become armed
      And partitions excluded by configuration retain their defined behaviour

  Rule: Only an authorized user can operate another partition

    @SYS-012 @ST-019
    Scenario: Authorized user operates another partition
      Given the user is operating Partition 1
      And the user is authorized to operate Partition 2
      When the user selects the Go To function for Partition 2
      Then the system displays Partition 2 status
      And the user can perform permitted operations on Partition 2

    @SYS-012 @ST-020
    Scenario: Unauthorized user cannot operate another partition
      Given the user is operating Partition 1
      And the user is not authorized to operate Partition 2
      When the user attempts to operate Partition 2
      Then the operation is rejected
      And Partition 2 remains unaffected by the unauthorized command

  Rule: Scheduled state changes occur at the configured condition

    @SYS-013 @ST-021
    Scenario: System arms at the configured scheduled time
      Given automatic arming is configured for a partition
      And the partition satisfies the configured arming conditions
      When the scheduled arming time is reached
      Then the system initiates the configured arming action

    @SYS-013 @ST-022
    Scenario: System does not arm before the configured condition is reached
      Given automatic arming is scheduled for a future time
      And the partition is disarmed
      When the current time is before the scheduled time
      Then the scheduled arming action does not occur

  Rule: User access is controlled by the configured access window

    @SYS-014 @ST-023
    Scenario: Authorized user operates within the permitted window
      Given a user-access time window is configured
      And the current time is within the permitted window
      When the authorized user requests a permitted operation
      Then the system allows the operation

    @SYS-014 @ST-024
    Scenario: User is denied access outside the permitted window
      Given a user-access time window is configured
      And the current time is outside the permitted window
      When the user requests an operation restricted by that window
      Then the system rejects the operation

  Rule: A configured macro executes its assigned action

    @SYS-015 @ST-025
    Scenario: Configured macro executes its assigned action
      Given a macro button is configured with an assigned action
      When the user activates the macro button
      Then the system executes the assigned action

    @SYS-015 @ST-026
    Scenario: Unconfigured macro does not execute an unintended action
      Given a macro button has no assigned action
      When the user activates the button
      Then no unintended system action occurs

  Rule: Only chime-enabled zones generate a chime

    @SYS-016 @ST-027
    Scenario: Chime-enabled zone generates a chime
      Given a zone is configured with chime enabled
      When the zone is activated
      Then the system generates the configured chime

    @SYS-016 @ST-028
    Scenario: Zone with chime disabled does not generate a chime
      Given a zone is configured with chime disabled
      When the zone is activated
      Then the system does not generate a zone chime

  Rule: Alarm reporting and remote communication operate through a configured supported IP communication interface

    @SYS-017 @ST-029
    Scenario: Configured IP communicator reports an alarm event
      Given a supported IP communicator is configured and connected
      And the system is armed
      When an intrusion alarm event occurs
      Then the configured IP communicator reports the alarm event

    @SYS-017 @ST-030
    Scenario: Unavailable IP path does not report an alarm successfully
      Given a supported IP communicator is configured
      And the IP communication path is unavailable
      When an intrusion alarm event occurs
      Then the IP alarm report is not marked as successfully delivered

    @SYS-017 @ST-031
    Scenario: Upload and download communication uses a supported IP interface
      Given a supported IP communication interface is configured and connected
      When an authorized upload or download operation is initiated
      Then the communication operation completes through the configured IP interface

  Rule: The system supports operation with 1 to 4 configured graphic touchscreen keypads

    @SYS-018 @ST-032
    Scenario: Four graphic touchscreen keypads are available for operation
      Given four supported graphic touchscreen keypads are configured and connected
      When the user accesses the system from each keypad
      Then each keypad is available for system operation

    @SYS-018 @ST-033
    Scenario: More than four graphic touchscreen keypads is outside supported capacity
      Given four supported graphic touchscreen keypads are configured
      When a configuration requiring a fifth graphic touchscreen keypad is attempted
      Then the configuration is identified as exceeding the supported capacity

  Rule: A wireless key can be configured without consuming a security zone

    @SYS-019 @ST-034
    Scenario: Wireless key operates without a zone assignment
      Given a wireless key is configured without a security zone assignment
      And the wireless key is assigned a supported action
      When the user activates the wireless key
      Then the configured action is performed
      And no security zone is consumed by the wireless key

  Rule: The system provides 8 onboard hardwired zones, or up to 15 with Zone Doubling

    @SYS-020 @ST-035
    Scenario: Eight onboard hardwired zones are available without Zone Doubling
      Given Zone Doubling is disabled
      When the installer configures the onboard hardwired zones
      Then eight onboard hardwired zones are available

    @SYS-020 @ST-036
    Scenario: Up to 15 onboard zones are available with Zone Doubling
      Given Zone Doubling is enabled and supported wiring is installed
      When the installer configures the onboard zones
      Then up to 15 onboard zones are available

  Rule: Hardwired expansion supports up to 40 expansion zones

    @SYS-021 @ST-037
    Scenario: Supported hardwired expansion provides 40 zones
      Given supported hardwired expansion modules are installed
      When the installer configures the maximum supported hardwired expansion
      Then 40 hardwired expansion zones are available

  Rule: Wireless expansion supports up to 40 expansion zones

    @SYS-022 @ST-038
    Scenario: Supported wireless expansion provides 40 zones
      Given supported wireless expansion hardware is installed
      When the installer configures the maximum supported wireless expansion
      Then 40 wireless expansion zones are available

  Rule: The combined system configuration supports a maximum of 48 total zones

    @SYS-023 @ST-039
    Scenario: Supported configuration with 48 total zones is accepted
      Given supported hardwired and or wireless expansion modules are installed
      When the installer configures 48 total zones
      Then the system accepts the supported 48-zone configuration

    @SYS-023 @ST-040
    Scenario: Configuration requiring a 49th zone exceeds supported capacity
      Given the system is configured with 48 total zones
      When the installer attempts to configure a 49th zone
      Then the configuration is identified as exceeding the supported capacity

  Rule: Each of the two onboard trigger outputs can perform its configured action

    @SYS-024 @ST-041
    Scenario: Onboard trigger output 1 performs its configured action
      Given trigger output 1 is configured with an activation condition and action
      When the activation condition occurs
      Then trigger output 1 performs its configured action

    @SYS-024 @ST-042
    Scenario: Onboard trigger output 2 performs its configured action
      Given trigger output 2 is configured with an activation condition and action
      When the activation condition occurs
      Then trigger output 2 performs its configured action

  Rule: User codes operate according to their assigned partition authorization

    @SYS-025 @ST-043
    Scenario: System supports 48 configured user codes
      Given 48 user codes are configured and assigned to applicable partitions
      When the installer reviews the configured user codes
      Then all 48 user codes are available according to their assignments

    @SYS-025 @ST-044
    Scenario: User assigned only to Partition 1 cannot perform protected operations on Partition 2
      Given a user code is assigned only to Partition 1
      And the user is not authorized for Partition 2
      When the user attempts a protected operation on Partition 2
      Then the operation is rejected
      And Partition 2 remains unaffected

  Rule: Two independent partitions maintain separate security states and support the common partition

    @SYS-026 @ST-045
    Scenario: Partition 1 can be armed while Partition 2 remains disarmed
      Given Partition 1 and Partition 2 are configured and disarmed
      When an authorized user arms Partition 1
      Then Partition 1 becomes armed
      And Partition 2 remains disarmed

    @SYS-026 @ST-046
    Scenario: Changing one independent partition does not change the other partition
      Given Partition 1 and Partition 2 are configured and disarmed
      When an authorized user changes the security state of Partition 1
      Then Partition 1 changes to the requested state
      And Partition 2 retains its previous security state

  Rule: Events associated with each partition use that partition's configured account number

    @SYS-027 @ST-047
    Scenario: Partition 1 event uses Partition 1 account number
      Given Partition 1 has a configured account number
      When an event associated with Partition 1 is reported
      Then the report uses the account number configured for Partition 1

    @SYS-027 @ST-048
    Scenario: Partition 2 event uses Partition 2 account number
      Given Partition 2 has a configured account number
      When an event associated with Partition 2 is reported
      Then the report uses the account number configured for Partition 2

  Rule: The system controls up to 16 configured output devices

    @SYS-028 @ST-049
    Scenario: Configuration containing 16 supported output devices is available for control
      Given 16 supported output devices are connected through supported output modules
      And each output device is configured
      When the user or system triggers a configured output action
      Then the configured output devices can be controlled

    @SYS-028 @ST-050
    Scenario: Configuration requiring a 17th output device exceeds supported capacity
      Given 16 supported output devices are configured
      When the installer attempts to configure a 17th output device
      Then the configuration is identified as exceeding the supported capacity

  Rule: Each of the four configurable zone types can be defined with its required attributes

    @SYS-029 @ST-051
    Scenario: Installer configures all four custom zone types
      Given the installer has access to zone configuration
      When the installer defines each of the four configurable zone types with its required attributes
      Then all four zone types are available for assignment to supported zones

  Rule: Supported four-wire and two-wire smoke detectors are recognized according to their configured interface

    @SYS-030 @ST-052
    Scenario: Four-wire smoke detector generates an indicated alarm
      Given a supported four-wire smoke detector is connected and configured
      When the smoke detector generates an alarm condition
      Then the system indicates the corresponding alarm

    @SYS-030 @ST-053
    Scenario: System operates with 16 supported two-wire smoke detectors
      Given 16 supported two-wire smoke detectors are connected and configured
      When the smoke detection system is checked for operation
      Then the configured two-wire smoke detectors are operational

    @SYS-030 @ST-054
    Scenario: Seventeenth two-wire smoke detector exceeds supported capacity
      Given 16 supported two-wire smoke detectors are configured
      When a configuration requiring a 17th two-wire smoke detector is attempted
      Then the configuration is identified as exceeding the supported capacity

  Rule: A supported detector maintenance signal is recognized by the system

    @SYS-031 @ST-055
    Scenario: Compatible smoke detector CleanMe signal is recognized
      Given a compatible smoke detector is connected
      When the detector generates a CleanMe maintenance signal
      Then the system recognizes and indicates the maintenance signal

  Rule: A configured output device performs the action assigned to the applicable system state

    @SYS-032 @ST-056
    Scenario: Configured light turns off when the system is armed
      Given a light output is configured to turn off when the system is armed
      When the system becomes armed
      Then the configured light turns off

    @SYS-032 @ST-057
    Scenario: Configured light turns on when the system is disarmed
      Given a light output is configured to turn on when the system is disarmed
      When the system becomes disarmed
      Then the configured light turns on

    @SYS-032 @ST-058
    Scenario: Configured light flashes during an alarm
      Given a light output is configured to flash during an alarm
      When the system enters the alarm state
      Then the configured light flashes

  Rule: A detected telephone-line fault activates the configured indication

    @SYS-033 @ST-059
    Scenario: Telephone-line fault is indicated on the keypad
      Given telephone-line cut monitoring is enabled
      And keypad fault indication is configured
      When the telephone line is cut
      Then the configured fault indication appears on the keypad after the configured delay

    @SYS-033 @ST-060
    Scenario: Telephone-line fault activates the configured local sounder
      Given telephone-line cut monitoring is enabled
      And local sounder annunciation is configured
      When the telephone line is cut and the configured delay expires
      Then the configured local sounder activates

    @SYS-033 @ST-061
    Scenario: Telephone-line fault activates the system bell when configured
      Given telephone-line cut monitoring is enabled
      And system bell annunciation is configured
      When the telephone line is cut and the configured delay expires
      Then the system bell activates

  Rule: A configured latchkey condition generates the associated pager report

    @SYS-034 @ST-062
    Scenario: Configured latchkey condition generates a pager report
      Given latchkey reporting is configured for a user or partition
      And the associated pager reporting destination is configured
      When the configured latchkey condition occurs
      Then the corresponding pager report is generated
